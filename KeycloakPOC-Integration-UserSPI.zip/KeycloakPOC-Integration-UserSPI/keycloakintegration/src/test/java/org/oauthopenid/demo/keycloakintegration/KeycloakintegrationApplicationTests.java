package org.oauthopenid.demo.keycloakintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class KeycloakintegrationApplicationTests {

	//@Test
	void contextLoads() {
	}

}
