package org.oauthopenid.demo.keycloakintegration.helper;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class PKCECodeVerifierAndChallangeGenerator {
	
	public static String generateCodeVerifier() throws UnsupportedEncodingException{
		SecureRandom secureRandom = new SecureRandom();
		byte[] codeVerifier = new byte[32];
		secureRandom.nextBytes(codeVerifier);
		String urlSafeCodeVerifierValue = Base64.getUrlEncoder().withoutPadding().encodeToString(codeVerifier);
		return urlSafeCodeVerifierValue;
		//sample value from this program = I4RSFZM3Wqr_nadKsJAI66DwvUiJ6paITmslJdeGyLY
	}
	
	
	public static String generateCodeChallange(String codeVerifier) throws UnsupportedEncodingException, NoSuchAlgorithmException{
		
		//Formula as listed in RFC 7636 is
		//code_challange = Base64Url-Encode(SHA256(ASCII(codeVerifier)))
		
		byte[] bytes = codeVerifier.getBytes("US-ASCII");
		
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.update(bytes,0,bytes.length);
		
		byte[] digest = md.digest();
		
		String codeChallange = Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
		
		return codeChallange;
		
	}
	
	public static void main(String[] args) {
		try {
			String codeVerifier = generateCodeVerifier();
			
			String codeChallange = generateCodeChallange(codeVerifier);
			
			System.out.println("Code Verifier = "+codeVerifier);
			System.out.println("Code Challange = "+codeChallange);
			
			/*
			Captured from previous run
			Code Verifier = Z7Umx7bUOnHO6C3hWQZEkwXbJXjQWjO75Cy47pIgt-U
			Code Challange = Vu_f76Zc1khC8j3Nhzv5Dhf-SSE7c0Vk3jC27mG22hQ
			*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
