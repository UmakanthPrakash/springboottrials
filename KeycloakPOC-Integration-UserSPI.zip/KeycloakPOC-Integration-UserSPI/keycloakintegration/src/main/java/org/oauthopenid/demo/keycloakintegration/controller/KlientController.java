package org.oauthopenid.demo.keycloakintegration.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/klient")
public class KlientController {
	
	@GetMapping("/user")
	public ResponseObject userendpoint(){
		ResponseObject ro = new ResponseObject();
		ro.setEndPoint("/user");
		ro.setMessage("Hello! You are in all user space");
		ro.setRolesAllowed("user");
		return ro;
	}
	
	@GetMapping("/communi5users")
	public ResponseObject communi5usersendpoint(){
		ResponseObject ro = new ResponseObject();
		ro.setEndPoint("/communi5users");
		ro.setMessage("Hello! You are in communi5 users space");
		ro.setRolesAllowed("communi5users");
		return ro;
	}
	
	@GetMapping("/communi5admin")
	public ResponseObject communi5adminendpoint(){
		ResponseObject ro = new ResponseObject();
		ro.setEndPoint("/communi5admin");
		ro.setMessage("Hello! You are in communi5 admin space");
		ro.setRolesAllowed("communi5admin");
		return ro;
	}

	@GetMapping("/admin")
	public ResponseObject adminendpoint(){
		ResponseObject ro = new ResponseObject();
		ro.setEndPoint("/admin");
		ro.setMessage("Hello! You are in all admin space");
		ro.setRolesAllowed("communi5admin");
		return ro;
	}
	
	@GetMapping("/welcome")
	public ResponseObject welcomeendpoint(){
		ResponseObject ro = new ResponseObject();
		ro.setEndPoint("/welcome");
		ro.setMessage("Hello! You are in general welcome page, please contact admin");
		ro.setRolesAllowed("all");
		return ro;
	}
	
}
