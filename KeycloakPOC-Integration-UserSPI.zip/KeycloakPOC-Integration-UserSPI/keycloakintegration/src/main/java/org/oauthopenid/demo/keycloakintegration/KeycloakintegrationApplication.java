package org.oauthopenid.demo.keycloakintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakintegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakintegrationApplication.class, args);
	}

}
