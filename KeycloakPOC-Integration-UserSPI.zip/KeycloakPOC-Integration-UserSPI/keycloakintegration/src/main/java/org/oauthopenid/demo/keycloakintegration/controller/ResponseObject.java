package org.oauthopenid.demo.keycloakintegration.controller;

public class ResponseObject {
	
	String endPoint;
	String message;
	String rolesAllowed;
	
	public String getEndPoint() {
		return endPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRolesAllowed() {
		return rolesAllowed;
	}
	public void setRolesAllowed(String rolesAllowed) {
		this.rolesAllowed = rolesAllowed;
	}

}
