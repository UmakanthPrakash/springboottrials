package communi5.keycloak.spi.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import communi5.keycloak.model.User;

public class MariaDBConnectionTest {
	String host = "localhost";
	int port = 3306;
	String database = "vas_core";
	String username = "root";
	String password = "root";

	private Connection getConnection(Properties info) throws SQLException {
		String url = "jdbc:mysql://" + host + ":" + port + "/" + database;
		info.setProperty("user", username);
		info.setProperty("password", password);
		return DriverManager.getConnection(url, info);
	}

	private void testConnect(Properties info, boolean sslExpected) throws SQLException {
		Connection conn = null;
		try {
			List<User> users = new ArrayList<>();
			
			conn = getConnection(info);
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,email from usr");
			while (rs.next()) {

				User user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));

				users.add(user);
			}
			rs.next();
			rs.close();

			// Check whether we're using SSL
			rs = stmt.executeQuery("SHOW STATUS LIKE 'ssl_cipher'");
			rs.next();
			String sslCipher = rs.getString(2);
			rs.close();
			boolean sslActual = sslCipher != null && sslCipher.length() > 0;
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
				}
			}
		}
	}


	public static void main(String[] args) throws SQLException {
		/*MariaDBConnectionTest mdct = new MariaDBConnectionTest();
		Properties info = new Properties();
		mdct.testConnect(info, false);*/
		
		MariaDBRepository mdrepo = new MariaDBRepository(new Properties());
		mdrepo.validateCredentials("admin@sp1.at", "communi5");
		
	}
}
