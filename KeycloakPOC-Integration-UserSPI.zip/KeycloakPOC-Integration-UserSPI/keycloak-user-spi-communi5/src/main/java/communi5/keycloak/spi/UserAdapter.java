package communi5.keycloak.spi;

import java.util.HashSet;
import java.util.Set;

import org.keycloak.component.ComponentModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.RoleModel;
import org.keycloak.storage.StorageId;
import org.keycloak.storage.adapter.AbstractUserAdapterFederatedStorage;

import communi5.keycloak.model.Role;
import communi5.keycloak.model.User;

public class UserAdapter extends AbstractUserAdapterFederatedStorage {

	private final User user;
	private final Set<RoleModel> userRoles = new HashSet<>();
	RealmModel realm;

	public UserAdapter(KeycloakSession session, RealmModel realm, ComponentModel model, User user) {
		super(session, realm, model);
		this.storageId = new StorageId(storageProviderModel.getId(), user.getId() + "");
		this.user = user;
		this.realm = realm;
		setFirstName(user.getFirst_name());
		setLastName(user.getLast_name());
		setEmail(user.getEmail());
		setEnabled(user.isEnabled());
	}

	@Override
	public String getUsername() {
		return user.getLogin_name();
	}

	@Override
	public void setUsername(String username) {
		user.setLogin_name(username);
	}

	@Override
	protected Set<RoleModel> getFederatedRoleMappings() {
		// addRealmRoles();
		addClientRoles();
		return userRoles;
	}

	private void addRealmRoles() {
		// As of now there are no relam roles for the user, hence this is left blank
	}

	private void addClientRoles() {
		realm.getClientsStream().forEach(client -> {
			if ("klient".equalsIgnoreCase(client.getClientId())) {
				client.getRolesStream().forEach(role -> {
					if (role.getName().equalsIgnoreCase("communi5users")) {
						this.userRoles.add(role);
					}
				});
			}
		});
	}

}
