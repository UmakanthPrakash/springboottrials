package communi5.keycloak.spi;

import org.keycloak.component.ComponentModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.provider.ProviderConfigProperty;
import org.keycloak.provider.ProviderConfigurationBuilder;
import org.keycloak.storage.UserStorageProviderFactory;

import communi5.keycloak.spi.repository.MariaDBRepository;

import java.util.List;
import java.util.Properties;


public class Communi5UserStorageProviderFactory implements UserStorageProviderFactory<Communi5UserStorageProvider> {

    @Override
    public Communi5UserStorageProvider create(KeycloakSession session, ComponentModel model) {

        MariaDBRepository repository = new MariaDBRepository(new Properties());

        return new Communi5UserStorageProvider(session, model, repository);
    }

    @Override
    public String getId() {
        return "communi5-users-spi";
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return ProviderConfigurationBuilder.create()
                .property("communi5", "Communi5-Users", "User DB for Communi5", ProviderConfigProperty.STRING_TYPE, "Communi5-Val", null)
                .build();
    }
}
