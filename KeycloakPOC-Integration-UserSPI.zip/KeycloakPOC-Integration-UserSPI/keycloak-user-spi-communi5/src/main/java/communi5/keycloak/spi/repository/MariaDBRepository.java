package communi5.keycloak.spi.repository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.bouncycastle.util.encoders.Hex;
import org.jboss.logging.Logger;

import communi5.keycloak.model.User;

public class MariaDBRepository {

	String host = "localhost";
	int port = 3306;
	String database = "vas_core";
	String username = "root";
	String password = "root";

	static Connection connection;
	
	private static final Logger LOGGER = Logger.getLogger(MariaDBRepository.class);


	public MariaDBRepository(Properties info) {
		LOGGER.info("MariaDBRepository constructor");
		Long created = System.currentTimeMillis();
		List<String> roles = Collections.singletonList("stoneage");

		String url = "jdbc:mysql://" + host + ":" + port + "/" + database;
		info.setProperty("user", username);
		info.setProperty("password", password);
		try {
			connection = DriverManager.getConnection(url, info);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<User> getAllUsers() {

		LOGGER.info("MariaDBRepository getAllUsers Enter");
		
		List<User> users = new ArrayList<>();

		Statement stmt;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,email from usr");
			while (rs.next()) {

				User user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));

				users.add(user);
			}
			rs.next();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository getAllUsers Exit, user size "+users.size());
		return users;
	}

	public int getUsersCount() {
		List<User> users = new ArrayList<>();

		Statement stmt;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,email from usr");
			while (rs.next()) {

				User user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));

				users.add(user);
			}
			rs.next();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository getUsersCount "+users.size());
		return users.size();
	}

	public User findUserById(String id) {
		Statement stmt;
		User user = null;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,email from usr where id = "+id);
			while (rs.next()) {

				user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));

				
			}
			rs.next();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository findUserById"+ user.toString());
		return user;
	}

	public User findUserByUsernameOrEmail(String username) {
		LOGGER.info("MariaDBRepository findUserByUsernameOrEmail "+username);
		Statement stmt;
		User user = null;
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,"
							+ "email from usr where login_name = '"+username+"' OR email = '"+username+"'");
			while (rs.next()) {

				user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));
				
			}
			rs.next();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository findUserByUsernameOrEmail"+ user.toString());
		return user;
	}

	public List<User> findUsers(String query) {
		LOGGER.info("MariaDBRepository findUsers "+query);
		Statement stmt;
		List<User> users = new ArrayList<>();
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT id,uuid,login_name,login_passwd,first_name,last_name,"
							+ "email from usr where login_name = '"+username+"' OR email = '"+username+"'");
			while (rs.next()) {

				User user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));
				users.add(user);
			}
			rs.next();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository findUsers"+ users.size());
		return users;
	}

	public boolean validateCredentials(String username, String password) {
		LOGGER.info("MariaDBRepository validateCredentials "+username +" "+password);
		Statement stmt;
		User user = null;
		
		try {
			
			//communi5
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash256 = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			String sha256hex = new String(Hex.encode(hash256));
			
			String query = "SELECT id,uuid,login_name,login_passwd,first_name,last_name,"
					+ "email from usr where login_name = '"+username+"' AND login_passwd = '"+sha256hex+"'";
			
			LOGGER.info("MariaDBRepository validateCredentials sha256hex of provided password "+sha256hex);
			LOGGER.info("MariaDBRepository validateCredentials sql "+query);
			
			stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery(query);
			while (rs.next()) {

				user = new User(rs.getInt("id"), rs.getString("uuid"), rs.getString("login_name"),
						rs.getString("login_passwd"), rs.getString("first_name"), rs.getString("last_name"),
						rs.getString("email"));
				
			}
			rs.next();
			rs.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("MariaDBRepository validateCredentials final return "+ user!=null);
		return user!=null;
	}

	public boolean updateCredentials(String username, String password) {
		//I will implement later
		return true;
	}

}
