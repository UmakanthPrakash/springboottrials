package communi5.keycloak.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class User {

	Integer id;
	String uuid;
	String login_name;
	String login_passwd;
	String first_name;
	String last_name;
	String email;
	private boolean enabled = true;

	public User(Integer id, String uuid, String login_name, String login_passwd, String first_name, String last_name,
			String email) {
		super();
		this.id = id;
		this.uuid = uuid;
		this.login_name = login_name;
		this.login_passwd = login_passwd;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
	}

	public User() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getLogin_name() {
		return login_name;
	}

	public void setLogin_name(String login_name) {
		this.login_name = login_name;
	}

	public String getLogin_passwd() {
		return login_passwd;
	}

	public void setLogin_passwd(String login_passwd) {
		this.login_passwd = login_passwd;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", uuid=" + uuid + ", login_name=" + login_name + ", login_passwd=" + login_passwd
				+ ", first_name=" + first_name + ", last_name=" + last_name + ", email=" + email + ", enabled="
				+ enabled + "]";
	}	
}
